export const generos = [
  //1
  {
    nombre: "Acción",
  },
  //2
  {
    nombre: "Aventura",
  },
  //3
  {
    nombre: "Juego de rol",
  },
  //4
  {
    nombre: "Multijugador",
  },
  //5
  {
    nombre: "Estrategia",
  },
  //6
  {
    nombre: "Plataformas",
  },
];
