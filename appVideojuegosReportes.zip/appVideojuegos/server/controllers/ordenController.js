const { PrismaClient, Prisma } = require("@prisma/client");

const prisma = new PrismaClient();
module.exports.get = async (request, response, next) => {
  const orden = await prisma.orden.findMany({
    orderBy: {
      fechaOrden: 'asc',
    },
    include: {
      usuario:true
    },
  });
  response.json(orden);
};
module.exports.getById = async (request, response, next) => {
  let id = parseInt(request.params.id);
  const orden = await prisma.orden.findUnique({
    where: {
      id: id,
    },
    include: {
      videojuegos: {
        select: {
          videojuego: true,
          cantidad: true,
        },
      },
      usuario:true
    },
  });
  response.json(orden);
};
//Método para crear ordenes
module.exports.create = async (req, res, next) => {
  
  let infoOrden=req.body; 
   
  const newVideojuego = await prisma.orden.create({
    data: {
      fechaOrden: infoOrden.fechaOrden,
      usuario:{ 
        connect:{id:1}
      },
      videojuegos: { 
        createMany: {
          data: infoOrden.videojuegos,
        },
      },
    },
  });
  res.json(newVideojuego);
};
module.exports.getVentaProductoMes = async (request, response, next) => {
  let mes = parseInt(request.params.mes)|1; 
  const result = await prisma.$queryRaw(
    Prisma.sql`SELECT v.nombre, SUM(ov.cantidad) as suma FROM orden o, ordenonvideojuego ov, videojuego v WHERE o.id=ov.ordenId and ov.videojuegoId=v.id AND MONTH(o.fechaOrden) = ${mes} GROUP BY ov.videojuegoId`
  )
  //SELECT v.nombre, SUM(ov.cantidad) as suma FROM orden o, ordenonvideojuego ov, videojuego v WHERE o.id=ov.ordenId and ov.videojuegoId=v.id AND MONTH(o.fechaOrden) = 10 GROUP BY ov.videojuegoId
  response.json(result);
};
module.exports.getVentaProductoTop = async (request, response, next) => {
  let mes = parseInt(request.params.mes)|1; 
  const result = await prisma.$queryRaw(
    Prisma.sql`SELECT v.nombre, (SUM(ov.cantidad)*v.precio) as total FROM orden o, ordenonvideojuego ov, videojuego v WHERE o.id=ov.ordenId and ov.videojuegoId=v.id GROUP BY ov.videojuegoId ORDER BY total DESC`
  )
  //SELECT v.nombre, (SUM(ov.cantidad)*v.precio) as total FROM orden o, ordenonvideojuego ov, videojuego v WHERE o.id=ov.ordenId and ov.videojuegoId=v.id GROUP BY ov.videojuegoId ORDER BY total DESC;
  response.json(result);
};